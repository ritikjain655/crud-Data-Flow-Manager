import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import "./EditUser.css"; // Importing the CSS file

function EditUser() {
    const navigate = useNavigate();
    const { empid } = useParams();
    const [empid2, setempid2] = useState("");
    const [name, setname] = useState("");
    const [phone, setphone] = useState("");
    const [email, setemail] = useState("");
    const [pid, setpid] = useState("");

    useEffect(() => {
        fetch("http://localhost:5001/user/?empid=" + empid)
            .then((res) => res.json())
            .then((data) => {
                setempid2(data[0].empid);
                setname(data[0].name);
                setphone(data[0].phone);
                setemail(data[0].email);
                setpid(data[0].id);
            })
            .catch((err) => console.log(err.message));
    }, [empid]);

    function handleEditSubmit(e) {
        e.preventDefault();
        const SendEditData = { empid: empid2, name, phone, email };

        fetch("http://localhost:4000/user/" + pid, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(SendEditData),
        })
            .then((res) => res.json())
            .catch((err) => console.log(err.message));

        alert("Data Updated");
        navigate("/userrecords");
    }

    return (
        <div className="edit-user-container">
            <h1>Please Enter The Updated Details</h1>
            <form onSubmit={handleEditSubmit} className="edit-user-form">
                <input type="text" placeholder="Employee ID" required value={empid2} onChange={(e) => setempid2(e.target.value)} />
                <input type="text" placeholder="Name" required value={name} onChange={(e) => setname(e.target.value)} />
                <input type="number" placeholder="Phone" required value={phone} onChange={(e) => setphone(e.target.value)} />
                <input type="text" placeholder="Email" required value={email} onChange={(e) => setemail(e.target.value)} />
                <button type="submit">Update Data</button>
                <Link to={"/userrecords"}><button className="back-button">Back</button></Link>
            </form>
        </div>
    );
}

export default EditUser;
