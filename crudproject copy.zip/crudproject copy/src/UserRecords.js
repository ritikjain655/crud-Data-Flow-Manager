import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "./UserRecords.css"; // Import the CSS file

function UserRecords() {
    let [userdata, setuserdata] = useState([]);

    useEffect(() => {
        fetch("http://localhost:5001/user")
            .then((res) => res.json())
            .then((data) => setuserdata(data))
            .catch((err) => console.log(err.message));
    }, []);

    return (
        <div className="user-container">
            <h2 className="user-heading">User Records</h2>
            <Link to={"/createuser"}>
                <button className="add-button">+ Add New User</button>
            </Link>
            
            <table className="user-table">
                <thead>
                    <tr>
                        <th>Employee ID</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {userdata.map((item, i) => (
                        <tr key={i}>
                            <td>{item.empid}</td>
                            <td>{item.name}</td>
                            <td>{item.phone}</td>
                            <td>{item.email}</td>
                            <td className="action-buttons">
                                <Link to={`/viewuser/${item.empid}`}>
                                    <button className="view-button">View</button>
                                </Link>
                                <Link to={`/edituser/${item.empid}`}>
                                    <button className="edit-button">Edit</button>
                                </Link>
                                <Link to={`/deleteuser/${item.id}`}>
                                    <button className="delete-button">Delete</button>
                                </Link>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default UserRecords;
