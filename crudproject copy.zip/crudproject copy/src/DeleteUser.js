import { useParams, useNavigate } from "react-router-dom";
import "./DeleteUser.css";

function DeleteUser() {
    const navigate = useNavigate();
    const { id } = useParams();

    function HandleDelete() {
        fetch("http://localhost:5001/user/" + id, { method: "DELETE" })
            .then(() => {
                alert("Data removed successfully");
                navigate("/userrecords");
            })
            .catch((err) => console.log(err.message));
    }

    return (
        <div className="delete-container">
            <div className="delete-message">
                Are you sure you want to delete this user?
            </div>
            <div className="button-group">
                <button className="delete-btn yes" onClick={HandleDelete}>YES</button>
                <button className="delete-btn no" onClick={() => navigate("/userrecords")}>NO</button>
            </div>
        </div>
    );
}

export default DeleteUser;
