
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import UserRecords from './UserRecords';
import CreateUser from './CreateUser';
import EditUser from './EditUser';
import ViewUser from './ViewUser';
import DeleteUser from './DeleteUser';


function App() {
  
  return (
    
    <BrowserRouter>
    <Routes>
      <Route path='/userrecords' element={<UserRecords />}></Route>
      <Route path='/createuser' element={<CreateUser />}></Route>
      <Route path='/edituser/:empid' element={<EditUser />}></Route>
      <Route path='/viewuser/:empid' element={<ViewUser />}></Route>
      <Route path='/deleteuser/:id' element={<DeleteUser />}></Route>
      <Route path='*' element={<div style={{textAlign:"center"}}>
        <h3>Error URL Not Found</h3>
        </div>}></Route>
    </Routes>
    </BrowserRouter>
  );
}

export default App;
