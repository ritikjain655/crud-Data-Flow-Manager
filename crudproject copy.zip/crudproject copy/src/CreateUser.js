import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./CreateUser.css"; // Importing the CSS file

function CreateUser() {
    const [empid, setempid] = useState("");
    const [name, setname] = useState("");
    const [phone, setphone] = useState("");
    const [email, setemail] = useState("");
    const navigate = useNavigate();

    function HandleSubmit(e) {
        e.preventDefault();
        const sendData = { empid, name, phone, email };

        fetch("http://localhost:5001/user", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(sendData)
        })
        .then((res) => res.json())
        .catch((e) => console.log(e.message));

        alert("Data saved");
        navigate("/userrecords");
    }

    return (
        <div className="create-user-container">
            <h3>Add User</h3>
            <form onSubmit={HandleSubmit} className="create-user-form">
                <input type="text" placeholder="Employee ID" required value={empid} onChange={(e) => setempid(e.target.value)} />
                <input type="text" placeholder="Name" required value={name} onChange={(e) => setname(e.target.value)} />
                <input type="number" placeholder="Phone" required value={phone} onChange={(e) => setphone(e.target.value)} />
                <input type="text" placeholder="Email" required value={email} onChange={(e) => setemail(e.target.value)} />
                <button type="submit">Submit Data</button>
                <Link to={"/userrecords"}><button className="back-button">Back</button></Link>
            </form>
        </div>
    );
}

export default CreateUser;
