import { Link, useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import "./ViewUser.css";

function ViewUser() {
    const { empid } = useParams();
    const [viewdata, setviewdata] = useState(null);

    useEffect(() => {
        fetch("http://localhost:50001/user/?empid=" + empid)
            .then((res) => res.json())
            .then((data) => setviewdata(data[0]))
            .catch((err) => console.log(err.message));
    }, [empid]);

    if (!viewdata) return <div className="view-container">Loading...</div>;

    return (
        <div className="view-container">
            <div className="view-title">User Details</div>
            <div className="view-info"><span>Name:</span> {viewdata.name}</div>
            <div className="view-info"><span>Emp ID:</span> {viewdata.empid}</div>
            <div className="view-info"><span>Email:</span> {viewdata.email}</div>
            <div className="view-info"><span>Contact:</span> {viewdata.phone}</div>
            <Link to={"/userrecords"}><button className="back-button">Back</button></Link>
        </div>
    );
}

export default ViewUser;
